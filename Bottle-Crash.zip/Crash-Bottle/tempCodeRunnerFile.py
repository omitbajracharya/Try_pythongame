                SCREEN.blit(font.render(f"{HIGHSCORE[1]}",1, (0, 0, 51)), (128,312))
